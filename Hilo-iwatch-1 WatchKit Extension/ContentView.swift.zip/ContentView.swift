//
//  ContentView.swift
//  Hilo-iwatch-1 WatchKit Extension
//
//  Created by ZHONG Sailin on 08.11.19.
//  Copyright © 2019 ZHONG Sailin. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State var currentCO2 = String(Int.random(in: 400 ..< 1500))
    var body: some View {
        
        ZStack {
           Circle()
            .fill(Color.white)
            .frame(width: 80, height: 80)
           Text(currentCO2)
            .font(.custom("", size: 35))
            .offset(y: -3)
            .foregroundColor(.black)
           Text("ppm")
            .font(.custom("", size: 15))
            .offset(y: 20)
            .foregroundColor(.black)
        }
    }
    
//    func getCO2(){
//        // test with random number
//        currentCO2 = String(Int.random(in: 400 ..< 1500))
//    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
